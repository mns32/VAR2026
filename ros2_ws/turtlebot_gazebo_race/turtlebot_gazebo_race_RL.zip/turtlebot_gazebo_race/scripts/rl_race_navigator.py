#!/usr/bin/env python3
"""
rl_race_navigator.py — Navegación con Aprendizaje por Refuerzo (Q-Learning)
para Turtlebot3 en el circuito de la Práctica 2 VAR.

Arquitectura:
  - Estado:   discretización del LiDAR en N_SECTORS sectores (izquierda, frente-izq,
              frente, frente-der, derecha) + velocidad lineal actual.
  - Acciones: 5 comandos de velocidad (giro-izq-fuerte, giro-izq, recto, giro-der, giro-der-fuerte)
  - Recompensa: +velocidad_lineal (avanza) − penalización_obstáculo − penalización_colisión
  - Modo warmup: gap-following reactivo (sin exploración, funciona desde el frame 1)
  - Una vez con tabla Q cargada, el agente explota directamente (epsilon→0).

Uso:
    # En la pestaña "Trabajo" del contenedor:
    python3 /home/ros2_ws/turtlebot_gazebo_race/scripts/rl_race_navigator.py

    # Con tabla Q previa (para continuar entrenamiento o solo explotar):
    python3 .../rl_race_navigator.py --qtable /tmp/qtable.pkl --mode exploit
"""

import argparse
import math
import os
import pickle
import random
import time
from collections import defaultdict

import numpy as np
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from sensor_msgs.msg import LaserScan

# ─── Hiperparámetros ──────────────────────────────────────────────────────────
ALPHA        = 0.15    # tasa de aprendizaje
GAMMA        = 0.90    # factor de descuento
EPSILON_START = 0.30   # exploración inicial
EPSILON_MIN  = 0.05    # exploración mínima
EPSILON_DECAY = 0.9995 # decay por paso

# Velocidades lineales y angulares para cada acción
LINEAR_VEL   = 0.22    # m/s — velocidad estándar
FAST_LINEAR  = 0.26    # m/s — velocidad en recta
ACTIONS = [
    # (v_lineal, v_angular)  — positivo=izquierda
    (LINEAR_VEL * 0.5, +1.0),   # 0: giro izquierda fuerte
    (LINEAR_VEL * 0.8, +0.5),   # 1: giro izquierda suave
    (FAST_LINEAR,       0.0),   # 2: recto
    (LINEAR_VEL * 0.8, -0.5),   # 3: giro derecha suave
    (LINEAR_VEL * 0.5, -1.0),   # 4: giro derecha fuerte
]

# Sectorización del LiDAR
N_SECTORS    = 5       # izq | frente-izq | frente | frente-der | der
DIST_BINS    = [0.25, 0.45, 0.70, 1.10, float('inf')]  # bins de distancia
DANGER_DIST  = 0.30    # m — distancia de colisión inminente

# Pesos de recompensa
R_FORWARD    =  1.0    # por cada m/s de avance
R_OBSTACLE   = -0.5    # penalización cuando hay obstáculo cercano en frente
R_CRASH      = -10.0   # penalización por colisión (laser muy cerca)
R_STOP       = -0.2    # penalización por estar casi parado

# Archivo de guardado automático de la tabla Q
QTABLE_SAVE_PATH = "/tmp/qtable_race.pkl"
SAVE_INTERVAL    = 500  # pasos entre guardados automáticos


class QLearningRaceNav(Node):
    """Nodo ROS2 con Q-Learning para navegar el circuito de carreras."""

    def __init__(self, qtable_path=None, mode="train"):
        super().__init__("rl_race_navigator")
        self.mode = mode  # "train" | "exploit"

        # ── Tabla Q ──────────────────────────────────────────────────────────
        self.q_table = defaultdict(lambda: np.zeros(len(ACTIONS)))
        if qtable_path and os.path.exists(qtable_path):
            with open(qtable_path, "rb") as f:
                data = pickle.load(f)
                for k, v in data.items():
                    self.q_table[k] = v
            self.get_logger().info(
                f"Tabla Q cargada desde {qtable_path} ({len(self.q_table)} estados)"
            )
        else:
            self.get_logger().info("Tabla Q inicializada vacía — modo exploración activa")

        # ── Estado del agente ─────────────────────────────────────────────────
        self.epsilon     = EPSILON_MIN if mode == "exploit" else EPSILON_START
        self.prev_state  = None
        self.prev_action = None
        self.step_count  = 0
        self.episode_reward = 0.0
        self.last_odom_v = 0.0

        # ── ROS2: publicadores y suscriptores ─────────────────────────────────
        self.cmd_pub = self.create_publisher(Twist, "/cmd_vel", 10)
        self.scan_sub = self.create_subscription(
            LaserScan, "/scan", self._scan_cb, 10
        )
        self.odom_sub = self.create_subscription(
            Odometry, "/odom", self._odom_cb, 10
        )

        self.get_logger().info(
            f"RL Race Navigator iniciado — modo={mode}, epsilon={self.epsilon:.3f}"
        )

    # ─── Callbacks ────────────────────────────────────────────────────────────

    def _odom_cb(self, msg: Odometry):
        """Guarda la velocidad lineal actual desde odometría."""
        self.last_odom_v = msg.twist.twist.linear.x

    def _scan_cb(self, msg: LaserScan):
        """Callback principal: recibe LiDAR, calcula estado, aplica Q-Learning."""
        ranges = np.array(msg.ranges, dtype=np.float32)
        ranges = np.where(np.isfinite(ranges), ranges, msg.range_max)
        ranges = np.clip(ranges, msg.range_min, msg.range_max)

        # ── Extraer sectores del LiDAR ────────────────────────────────────────
        n = len(ranges)
        # Turtlebot3 waffle: 0° = frente, 90° = izquierda, 270° = derecha
        # Sectores: [izq | f-izq | frente | f-der | der]
        sector_angles = [
            (60,  120),   # izquierda
            (30,   60),   # frente-izquierda
            (350,  10),   # frente (wrapping alrededor de 0)
            (300, 330),   # frente-derecha
            (240, 300),   # derecha
        ]
        sector_mins = []
        for (a_start, a_end) in sector_angles:
            if a_start < a_end:
                idx_start = int(a_start / 360.0 * n)
                idx_end   = int(a_end   / 360.0 * n)
                sector = ranges[idx_start:idx_end]
            else:
                # wrap-around (ej. 350..10)
                idx_s = int(a_start / 360.0 * n)
                idx_e = int(a_end   / 360.0 * n)
                sector = np.concatenate([ranges[idx_s:], ranges[:idx_e]])
            sector_mins.append(float(np.min(sector)) if len(sector) > 0 else msg.range_max)

        state = self._discretize_state(sector_mins)

        # ── Recompensa ────────────────────────────────────────────────────────
        reward = self._compute_reward(sector_mins)

        # ── Q-Learning update ─────────────────────────────────────────────────
        if self.prev_state is not None and self.mode == "train":
            self._update_q(self.prev_state, self.prev_action, reward, state)

        # ── Selección de acción ───────────────────────────────────────────────
        action_idx = self._select_action(state, sector_mins)

        # ── Publicar cmd_vel ──────────────────────────────────────────────────
        v, w = ACTIONS[action_idx]
        # Seguridad: si hay obstáculo MUY cerca al frente, forzar giro
        front_min = min(sector_mins[1], sector_mins[2], sector_mins[3])
        if front_min < DANGER_DIST:
            # Girar hacia el lado con más espacio
            if sector_mins[0] > sector_mins[4]:  # más espacio a la izquierda
                v, w = 0.05, +1.4
            else:
                v, w = 0.05, -1.4

        twist = Twist()
        twist.linear.x  = float(v)
        twist.angular.z = float(w)
        self.cmd_pub.publish(twist)

        # ── Actualizar estado ─────────────────────────────────────────────────
        self.prev_state  = state
        self.prev_action = action_idx
        self.step_count += 1
        self.episode_reward += reward

        # ── Decaer epsilon ────────────────────────────────────────────────────
        if self.mode == "train":
            self.epsilon = max(EPSILON_MIN, self.epsilon * EPSILON_DECAY)

        # ── Log periódico ──────────────────────────────────────────────────────
        if self.step_count % 100 == 0:
            self.get_logger().info(
                f"Paso {self.step_count:6d} | ε={self.epsilon:.3f} | "
                f"R_acum={self.episode_reward:8.2f} | "
                f"Q-estados={len(self.q_table)} | "
                f"Sectores=[{','.join(f'{d:.2f}' for d in sector_mins)}]"
            )

        # ── Guardado automático ───────────────────────────────────────────────
        if self.step_count % SAVE_INTERVAL == 0 and self.mode == "train":
            self._save_qtable(QTABLE_SAVE_PATH)

    # ─── Discretización ───────────────────────────────────────────────────────

    def _discretize_dist(self, d: float) -> int:
        """Convierte una distancia continua en un bin discreto."""
        for i, threshold in enumerate(DIST_BINS):
            if d <= threshold:
                return i
        return len(DIST_BINS) - 1

    def _discretize_state(self, sector_mins: list) -> tuple:
        """Convierte los mínimos sectoriales en un estado discreto (tupla hashable)."""
        return tuple(self._discretize_dist(d) for d in sector_mins)

    # ─── Recompensa ───────────────────────────────────────────────────────────

    def _compute_reward(self, sector_mins: list) -> float:
        """Calcula la recompensa para el estado actual."""
        front_min = min(sector_mins[1], sector_mins[2], sector_mins[3])

        # Recompensa por avanzar
        r = R_FORWARD * max(0.0, self.last_odom_v)

        # Penalización por obstáculo cercano al frente
        if front_min < 0.50:
            r += R_OBSTACLE * (0.50 - front_min) / 0.50

        # Penalización por colisión inminente
        if front_min < DANGER_DIST:
            r += R_CRASH * 0.5

        # Penalización por estar casi detenido
        if self.last_odom_v < 0.05:
            r += R_STOP

        return r

    # ─── Selección de acción ─────────────────────────────────────────────────

    def _select_action(self, state: tuple, sector_mins: list) -> int:
        """Selecciona acción con política ε-greedy + gap-following como fallback."""
        if self.mode == "train" and random.random() < self.epsilon:
            # Exploración: gap-following reactivo (mejor que random puro)
            return self._gap_following_action(sector_mins)

        # Explotación: mejor acción de la tabla Q
        q_vals = self.q_table[state]
        if np.all(q_vals == 0):
            # Estado nunca visto → gap-following
            return self._gap_following_action(sector_mins)
        return int(np.argmax(q_vals))

    def _gap_following_action(self, sector_mins: list) -> int:
        """
        Controlador reactivo gap-following:
        dirige el robot hacia el sector con mayor distancia libre.
        Funciona bien sin entrenamiento previo.
        """
        # Índices: 0=izq, 1=f-izq, 2=frente, 3=f-der, 4=der
        best_sector = int(np.argmax(sector_mins))

        # Mapear sector → acción
        # izq(0)→giro-izq-fuerte(0), f-izq(1)→giro-izq(1),
        # frente(2)→recto(2), f-der(3)→giro-der(3), der(4)→giro-der-fuerte(4)
        sector_to_action = {0: 0, 1: 1, 2: 2, 3: 3, 4: 4}
        action = sector_to_action[best_sector]

        # Si el frente está muy abierto pero los laterales también → recto rápido
        if sector_mins[2] > 1.0 and sector_mins[1] > 0.5 and sector_mins[3] > 0.5:
            action = 2

        return action

    # ─── Actualización Q-Learning ─────────────────────────────────────────────

    def _update_q(self, state, action, reward, next_state):
        """Actualización de Bellman (Q-Learning off-policy)."""
        q_current  = self.q_table[state][action]
        q_next_max = np.max(self.q_table[next_state])
        td_target  = reward + GAMMA * q_next_max
        self.q_table[state][action] += ALPHA * (td_target - q_current)

    # ─── Guardado / Carga ─────────────────────────────────────────────────────

    def _save_qtable(self, path: str):
        """Guarda la tabla Q en disco."""
        with open(path, "wb") as f:
            pickle.dump(dict(self.q_table), f)
        self.get_logger().info(
            f"Tabla Q guardada en {path} ({len(self.q_table)} estados)"
        )

    def on_shutdown(self):
        """Detener el robot y guardar la tabla Q al cerrar."""
        twist = Twist()
        self.cmd_pub.publish(twist)
        if self.mode == "train":
            self._save_qtable(QTABLE_SAVE_PATH)
        self.get_logger().info("Navigator detenido.")


# ─── Main ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="RL Race Navigator (Q-Learning)")
    parser.add_argument(
        "--qtable", type=str, default=None,
        help="Ruta a la tabla Q preentrenada (.pkl)"
    )
    parser.add_argument(
        "--mode", type=str, default="train", choices=["train", "exploit"],
        help="'train' (explora+aprende) o 'exploit' (solo usa tabla Q)"
    )
    # Evitar que argparse consuma los args de rclpy
    args, _ = parser.parse_known_args()

    rclpy.init()
    node = QLearningRaceNav(qtable_path=args.qtable, mode=args.mode)
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.on_shutdown()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()

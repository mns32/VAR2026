"""
launch/rl_navigator.launch.py — Lanza solo el nodo de navegación RL.

Uso (desde dentro del contenedor, con workspace sourceado):
    ros2 launch turtlebot_gazebo_race rl_navigator.launch.py
    ros2 launch turtlebot_gazebo_race rl_navigator.launch.py mode:=exploit qtable:=/tmp/qtable_race.pkl
"""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    mode_arg = DeclareLaunchArgument(
        "mode",
        default_value="train",
        description="'train' (explora y aprende) o 'exploit' (usa tabla Q guardada)"
    )
    qtable_arg = DeclareLaunchArgument(
        "qtable",
        default_value="",
        description="Ruta al fichero .pkl de la tabla Q (opcional)"
    )

    navigator_node = Node(
        package="turtlebot_gazebo_race",
        executable="rl_race_navigator",
        name="rl_race_navigator",
        output="screen",
        parameters=[{"use_sim_time": True}],
        arguments=[
            "--mode", LaunchConfiguration("mode"),
            "--qtable", LaunchConfiguration("qtable"),
        ],
    )

    return LaunchDescription([
        mode_arg,
        qtable_arg,
        navigator_node,
    ])
